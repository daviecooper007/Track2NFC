@echo off
echo ========================================
echo Building Track2NFC APK
echo ========================================

set JAVA_HOME=C:\tools\java\jdk-21.0.5+11
set PATH=%JAVA_HOME%\bin;C:\tools\gradle\gradle-8.5\bin;%PATH%
set ANDROID_HOME=C:\Users\%USERNAME%\AppData\Local\Android\Sdk

echo JAVA_HOME=%JAVA_HOME%
echo ANDROID_HOME=%ANDROID_HOME%
echo.

echo Checking Java...
java -version
echo.

echo Checking Gradle...
gradle -version
echo.

echo Checking Android SDK...
%ANDROID_HOME%\platform-tools\adb.exe version
echo.

echo Starting build...
cd /d C:\tools\Track2NFC_Fixed
gradle assembleDebug --no-daemon

echo.
echo ========================================
if exist app\build\outputs\apk\debug\app-debug.apk (
    echo BUILD SUCCESS!
    echo APK location: app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo To install on device:
    echo %ANDROID_HOME%\platform-tools\adb.exe install -r app\build\outputs\apk\debug\app-debug.apk
) else (
    echo BUILD FAILED - Check errors above
)
echo ========================================
pause