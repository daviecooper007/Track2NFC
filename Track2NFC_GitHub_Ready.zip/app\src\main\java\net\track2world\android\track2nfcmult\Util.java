package net.track2world.android.track2nfcmult;

/**
 * Utility functions for hex/byte conversion.
 */
public class Util {
    /**
     * Convert byte array to hex string.
     */
    public static String byteArrayToHex(byte[] bytes) {
        if (bytes == null) return "";
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    /**
     * Convert hex string to byte array.
     */
    public static byte[] hexToByteArray(String hex) {
        if (hex == null || hex.length() % 2 != 0) return new byte[0];
        int length = hex.length();
        byte[] bytes = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            int high = Character.digit(hex.charAt(i), 16);
            int low = Character.digit(hex.charAt(i + 1), 16);
            if (high == -1 || low == -1) return new byte[0];
            bytes[i / 2] = (byte) ((high << 4) | low);
        }
        return bytes;
    }
}