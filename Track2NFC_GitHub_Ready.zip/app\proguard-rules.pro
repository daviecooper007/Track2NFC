# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# Keep our main classes
-keep class net.track2world.android.track2nfcmult.** { *; }

# Keep HCE service
-keep class net.track2world.android.track2nfcmult.ServicoPagamento { *; }

# Keep Guava classes used by the app
-keep class com.google.common.** { *; }

# Keep AndroidX classes
-keep class androidx.** { *; }