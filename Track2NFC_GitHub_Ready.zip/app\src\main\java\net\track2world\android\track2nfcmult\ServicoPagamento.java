package net.track2world.android.track2nfcmult;

import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.cardemulation.HostApduService;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.common.primitives.Bytes;
import com.google.common.primitives.UnsignedBytes;

import java.util.Arrays;
import java.util.Objects;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Host Apdu Service for NFC payment emulation.
 * Handles APDU commands from payment terminals and responds with emulated card data.
 */
public class ServicoPagamento extends HostApduService implements SharedPreferences.OnSharedPreferenceChangeListener {

    private static final String TAG = "ServicoPagamento";
    private static final Pattern TRACK2_PATTERN = Pattern.compile("(\\d{12,29})=(\\d{2})(\\d{2})(\\d{3})(\\d+)");

    // APDU Commands
    private static final byte[] PPSE_APDU_SELECT = Util.hexToByteArray("00A404000E325041592E5359532E444446303100");
    private static final byte[] GPO_COMMAND = {UnsignedBytes.MAX_POWER_OF_TWO, (byte) 0xA8, 0x00, 0x00};
    private static final byte[] GEN_AC = {UnsignedBytes.MAX_POWER_OF_TWO, (byte) 0xAE, 0x00, 0x00};
    private static final byte[] GET_SE = {0x00, (byte) 0xA4, 0x04, 0x00, 0x07};

    // ISO 7816 error response
    private static final byte[] UNKNOWN_ERROR_RESPONSE = {(byte) 0x6A, (byte) 0x82};

    // Dynamic APDU responses (populated from track2 data)
    private byte[] selectResponse = new byte[0];
    private byte[] gpoResponse = new byte[0];
    private byte[] readRecResponse = new byte[0];
    private byte[] readRecResponse1 = new byte[0];
    private byte[] readRecResponse2 = new byte[0];
    private byte[] readRecResponse3 = new byte[0];
    private byte[] readRecResponse4 = new byte[0];
    private byte[] readRecResponse5 = new byte[0];
    private byte[] genAcResponse0 = new byte[0];
    private byte[] genAcResponse1 = new byte[0];
    private byte[] genAcResponse2 = new byte[0];
    private byte[] genAcResponse3 = new byte[0];

    // Read record commands (configured per card)
    private byte[] readRecCommand = new byte[0];
    private byte[] readRecCommand1 = new byte[0];
    private byte[] readRecCommand2 = new byte[0];
    private byte[] readRecCommand3 = new byte[0];
    private byte[] readRecCommand4 = new byte[0];
    private byte[] readRecCommand5 = new byte[0];

    private String currentTrack2Data = "";
    private String currentScript = "script_1";
    private int genAcCounter = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service created");

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        currentTrack2Data = prefs.getString(Fixo.SWIPE_DATA_PREF_KEY, Fixo.DEFAULT_SWIPE_DATA);
        currentScript = prefs.getString(Fixo.SWIPE_SCRIPT, Fixo.SWIPE_SCRIPT_DEFAULT);

        configureResponses(currentTrack2Data);
        configureSelectResponse();
        configurePpseResponse();

        prefs.registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onDeactivated(int reason) {
        Log.d(TAG, "Service deactivated: " + reason);
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        Log.d(TAG, "Preference changed: " + key);
        if (Fixo.SWIPE_DATA_PREF_KEY.equals(key)) {
            currentTrack2Data = sharedPreferences.getString(key, Fixo.DEFAULT_SWIPE_DATA);
            configureResponses(currentTrack2Data);
        } else if (Fixo.SWIPE_SCRIPT.equals(key)) {
            currentScript = sharedPreferences.getString(key, Fixo.SWIPE_SCRIPT_DEFAULT);
            configureSelectResponse();
            configureResponses(currentTrack2Data);
        }
    }

    @Override
    public byte[] processCommandApdu(byte[] commandApdu, Bundle extras) {
        String hexCommand = Util.byteArrayToHex(commandApdu);
        Log.d(TAG, "Received APDU: " + hexCommand);

        byte[] response;

        if (Arrays.equals(PPSE_APDU_SELECT, commandApdu)) {
            response = selectResponse; // PPSE response
            Log.d(TAG, "PPSE Select");
        } else if (isGetSelect(commandApdu)) {
            configureSelectResponseForAid(commandApdu);
            response = selectResponse;
            Log.d(TAG, "AID Select");
        } else if (isGpoCommand(commandApdu)) {
            response = gpoResponse;
            Log.d(TAG, "GPO Command");
        } else if (isGenAcCommand(commandApdu)) {
            response = getGenAcResponse();
            Log.d(TAG, "GEN AC Command, counter: " + genAcCounter);
        } else if (Arrays.equals(readRecCommand, commandApdu)) {
            response = readRecResponse;
            Log.d(TAG, "Read Record 1");
        } else if (Arrays.equals(readRecCommand1, commandApdu)) {
            response = readRecResponse1;
            Log.d(TAG, "Read Record 2");
        } else if (Arrays.equals(readRecCommand2, commandApdu)) {
            response = readRecResponse2;
            Log.d(TAG, "Read Record 3");
        } else if (Arrays.equals(readRecCommand3, commandApdu)) {
            response = readRecResponse3;
            Log.d(TAG, "Read Record 4");
        } else if (Arrays.equals(readRecCommand4, commandApdu)) {
            response = readRecResponse4;
            Log.d(TAG, "Read Record 5");
        } else if (Arrays.equals(readRecCommand5, commandApdu)) {
            response = readRecResponse5;
            Log.d(TAG, "Read Record 6");
        } else {
            response = UNKNOWN_ERROR_RESPONSE;
            Log.w(TAG, "Unhandled APDU: " + hexCommand);
        }

        Log.d(TAG, "Response: " + Util.byteArrayToHex(response));
        return response;
    }

    private boolean isGetSelect(byte[] apdu) {
        return apdu.length >= 7 && 
               apdu[0] == GET_SE[0] && apdu[1] == GET_SE[1] && 
               apdu[2] == GET_SE[2] && apdu[3] == GET_SE[3] && 
               apdu[4] == GET_SE[4];
    }

    private boolean isGpoCommand(byte[] apdu) {
        return apdu.length >= 4 && 
               apdu[0] == GPO_COMMAND[0] && apdu[1] == GPO_COMMAND[1] &&
               apdu[2] == GPO_COMMAND[2] && apdu[3] == GPO_COMMAND[3];
    }

    private boolean isGenAcCommand(byte[] apdu) {
        return apdu.length >= 2 && 
               apdu[0] == GEN_AC[0] && apdu[1] == GEN_AC[1];
    }

    private byte[] getGenAcResponse() {
        byte[] response;
        switch (genAcCounter) {
            case 0: response = genAcResponse0; break;
            case 1: response = genAcResponse1; break;
            case 2: response = genAcResponse2; break;
            case 3: response = genAcResponse3; break;
            default: response = genAcResponse0; break;
        }
        genAcCounter = (genAcCounter + 1) % 4;
        return response;
    }

    /**
     * Configure AID select response based on card type and script.
     */
    private void configureSelectResponse() {
        if (currentTrack2Data.isEmpty()) return;

        Matcher matcher = TRACK2_PATTERN.matcher(currentTrack2Data);
        if (!matcher.matches()) {
            Log.w(TAG, "Invalid track2 data for select response");
            return;
        }

        int firstDigit = Character.getNumericValue(currentTrack2Data.charAt(0));
        String cardType = getCardType();

        // Select appropriate AID based on card brand
        String aid;
        if ("Credit".equals(cardType)) {
            if (firstDigit == 4 || firstDigit == 6) aid = "A0000000031010"; // Visa Credit
            else if (firstDigit == 5) aid = "A0000000041010"; // Mastercard Credit
            else if (firstDigit == 3) aid = "A000000025010000"; // Amex
            else aid = "A0000000031010";
        } else { // Debit
            if (firstDigit == 4) aid = "A0000000032010"; // Visa Debit
            else if (firstDigit == 5) aid = "A0000000043060"; // Maestro/Mastercard Debit
            else if (firstDigit == 3) aid = "A000000025010000"; // Amex
            else aid = "A0000000032010";
        }

        // Build FCI response
        String fci = buildFciResponse(aid, firstDigit, cardType);
        selectResponse = Util.hexToByteArray(fci);
    }

    private void configureSelectResponseForAid(byte[] selectApdu) {
        // Extract AID from select command
        if (selectApdu.length < 7) return;
        int aidLength = selectApdu[6] & 0xFF;
        if (selectApdu.length < 7 + aidLength) return;

        byte[] aidBytes = Arrays.copyOfRange(selectApdu, 7, 7 + aidLength);
        String aid = Util.byteArrayToHex(aidBytes);
        Log.d(TAG, "Select AID: " + aid);

        // Reconfigure based on selected AID
        int firstDigit = Character.getNumericValue(currentTrack2Data.charAt(0));
        String cardType = getCardType();
        String fci = buildFciResponse(aid, firstDigit, cardType);
        selectResponse = Util.hexToByteArray(fci);
    }

    private String buildFciResponse(String aid, int firstDigit, String cardType) {
        StringBuilder fci = new StringBuilder();
        fci.append("6F"); // FCI Template
        
        // AID tag
        String aidLen = String.format("%02X", aid.length() / 2);
        fci.append("84").append(aidLen).append(aid);
        
        // FCI Proprietary Template
        StringBuilder proprietary = new StringBuilder();
        
        // Label
        String label = (firstDigit == 3) ? "AMEX" : (firstDigit == 4) ? "VISA" : "MASTERCARD";
        if ("Debit".equals(cardType)) label += " DEBIT";
        String labelHex = Util.byteArrayToHex(label.getBytes());
        proprietary.append("9F12").append(String.format("%02X", labelHex.length() / 2)).append(labelHex);
        
        // PDOL
        proprietary.append("9F38189F66049F02069F03069F1A0295055F2A029A039C019F3704BF0C089F5A050008400840");
        
        String propHex = proprietary.toString();
        fci.append("A5").append(String.format("%02X", propHex.length() / 2)).append(propHex);
        fci.append("9000");
        
        return fci.toString();
    }

    /**
     * Configure PPSE response (list of supported AIDs).
     */
    private void configurePpseResponse() {
        int firstDigit = currentTrack2Data.length() > 0 ? 
                Character.getNumericValue(currentTrack2Data.charAt(0)) : 4;
        String cardType = getCardType();

        StringBuilder ppse = new StringBuilder("6F6D840E325041592E5359532E4444463031A55BBF0C58");
        
        // Visa Credit AID
        ppse.append("294F07A0000000031010500C");
        ppse.append(Util.byteArrayToHex(("VISA " + (cardType.equals("Credit") ? "CREDIT" : "DEBIT")).getBytes()));
        ppse.append("8701019F12");
        ppse.append(String.format("%02X", ("VISA " + (cardType.equals("Credit") ? "CREDIT" : "DEBIT")).length()));
        ppse.append(Util.byteArrayToHex(("VISA " + (cardType.equals("Credit") ? "CREDIT" : "DEBIT")).getBytes()));
        
        // Visa Debit AID
        ppse.append("612B4F07A0000000032010500D");
        ppse.append(Util.byteArrayToHex(("VISA " + (cardType.equals("Debit") ? "DEBIT" : "CREDIT")).getBytes()));
        ppse.append("8701029F12");
        ppse.append(String.format("%02X", ("VISA " + (cardType.equals("Debit") ? "DEBIT" : "CREDIT")).length()));
        ppse.append(Util.byteArrayToHex(("VISA " + (cardType.equals("Debit") ? "DEBIT" : "CREDIT")).getBytes()));
        
        ppse.append("9000");
        
        selectResponse = Util.hexToByteArray(ppse.toString());
    }

    /**
     * Configure all dynamic responses based on track2 data.
     */
    private void configureResponses(String track2Data) {
        if (track2Data == null || track2Data.isEmpty()) {
            Log.w(TAG, "Empty track2 data");
            return;
        }

        Matcher matcher = TRACK2_PATTERN.matcher(track2Data);
        if (!matcher.matches()) {
            Log.w(TAG, "Track2 pattern mismatch: " + track2Data);
            return;
        }

        String pan = matcher.group(1);
        String year = matcher.group(2);
        String month = matcher.group(3);
        String serviceCode = matcher.group(4);
        String discretionary = matcher.groupCount() >= 5 ? matcher.group(5) : "";
        
        int firstDigit = Character.getNumericValue(pan.charAt(0));
        String script = currentScript;
        boolean isScript2 = "script_2".equals(script);

        Log.d(TAG, "Configuring responses: PAN=" + pan + ", Exp=" + month + "/" + year + ", Script=" + script);

        if (isScript2) {
            configureScript2Responses(pan, year, month, serviceCode, discretionary, firstDigit);
        } else {
            configureScript1Responses(pan, year, month, serviceCode, discretionary, firstDigit);
        }

        genAcCounter = 0;
    }

    /**
     * Script 1: Basic EMV responses
     */
    private void configureScript1Responses(String pan, String year, String month, String serviceCode, 
                                           String discretionary, int firstDigit) {
        // GPO Response
        String gpoData = "778182020040940C180101011001010010030300";
        String atc = String.format("%04X", new Random().nextInt(0xFFFF));
        String atcHex = "9F1020" + atc + "9F2608" + getRandomHex(16) + "9F2701409F3602" + getRandomNumber(4);
        String gpo = "77" + String.format("%02X", (gpoData.length() + atcHex.length()) / 2) + gpoData + atcHex + "9000";
        gpoResponse = Util.hexToByteArray(gpo);

        // Read Record commands
        readRecCommand = Util.hexToByteArray("00B2011C00");
        readRecCommand1 = Util.hexToByteArray("00B2011400");
        readRecCommand2 = Util.hexToByteArray("00B2031400");
        readRecCommand3 = Util.hexToByteArray("00B2040C00");
        readRecCommand4 = Util.hexToByteArray("00B2050C00");
        readRecCommand5 = Util.hexToByteArray("00B2060C00");

        // Build Track 2 Equivalent Data (Tag 57)
        String track2Equivalent = buildTrack2Equivalent(pan, year, month, serviceCode, discretionary);
        
        // Record 1: Application Template with Track 2 Equivalent
        String rec1 = "70" + String.format("%02X", (track2Equivalent.length() + 10) / 2) + 
                      "5A" + String.format("%02X", pan.length() / 2) + pan + 
                      "5F2403" + year + month + "28" + track2Equivalent + "9000";
        readRecResponse = Util.hexToByteArray(rec1);

        // Remaining records with static data
        readRecResponse1 = Util.hexToByteArray("7081DC8F01059081B066384A8DF96727829B400ECDA995881BB7CB3E965286EBD3705C12F80DB29238FE373BB6590B64622E9A22C91D013E9239B4DBD17AA7155A58287E78377A0E0DF65EA09DE3C39E4758995255E9EF065FD0937AB1668993752844FEA70DD99FED013677936EFBB0EC9735DDA44A81298581C0B1564B69CAC183F9874A4E72E404EBEA11796FDF88E484C5F0C0635AC3B4746636AA5CCCEB864AE2C9D923CDFFB828AE799D195A20AEA7816714A3C641699224569D59F577E4BE39F57180EFDC7B111A0D4D59E809878B47899B932282E95EF3CABDDF6D9000");
        readRecResponse2 = Util.hexToByteArray("7081B79F3201039381B0438C8460F38571DC63D464DF8E40F391AF6C37AA17E32252492E95AA8C27B3FB14DC1FA0449CE3237858E65DABB3105C4C146C9EAA86AE0B3225684AF1A7B4867A6EDF1C9FB423FA294CDCC0D2EFB09FF0CB7DB55D4911BCE51902E33B36D93B06D98147CC86186106F590D14929DA3260183F9F460B8B0A6CC9C305A73333D575B3E632C0FA17D72B627AC5052658BEEFE89FB58BEDDD032E439A7714B3161DF441D0CEEB6EE6839A594BA7EEF703509000");
        readRecResponse3 = Util.hexToByteArray("7081B39381B0585701AB3D383A7D43BB1C067E03A7E8CDB5F069FFA1BABB57FB76D91387EEF587C7E4D2976564FF511110422CA1B68AEA1D6DD0452897B9F94540A6DBE020434BE9A416145480C5B59A74893269E1DF59F9A251985CF21D1F4E2367FA7C4768090FBC5C985818057F6D7F51F78EF0C0ED1B92E06E9376A21C837A7A23F7EB9B2F59EC7AC8E6D2CC89CC89D9E95CBFF1B95B22B45E4D729DCC314551E56A9457F919C7DB0411119F1D1A0E96ECD9F4FE");
        readRecResponse4 = Util.hexToByteArray("7081E09081B043346B6855F28975EB6CDA546AD2DF2822DD1A404884EC7819EF9D422F45C7434A020E0B7F6F8E03B73DDFE1404A840FE99A32B27314CE05C460061EEABB6AD57B8A0682DA70CBFA17C7BAAA72CC4042189FC0D0629FCDB1315468F8EFC04FB90101572A271A5EAA40428A5C266B871E47AB432568EB8206AE3B379C5BBFD74CAE7C58B03BC3FDC4AC1FE5933FF5FD6ABBBA74BFBC9A78B01E3E0680B0A2D2D850187D86EE66F66CBBB39BA9B11A5A438F01059F32010392246FDC65F6FBFF12F50A1C99B9C76E7D6A3EDA0014B8B5C80D5D9CEC0051DA3DC091088371");
        readRecResponse5 = readRecResponse4;

        // GEN AC Responses
        String randomHex = getRandomHex(16);
        genAcResponse0 = Util.hexToByteArray("7781A29F2701809F360200079F4B818013783113B4B15DBD5D7211B82B252DF97754F17C4B9BFB9769001F0CC554DC6AAA8B463A0CF8423E2E81824D8FDB18D28DA84DF196E479EF36B6B659872CC6564898F9D2875E8E18A30E3035ECB5FA7200ED7EE969A531530CACADE29CB790B62F300F11E332F0FCA32B7BEDBBEC16B8B70D604E7F22EB99B85F54B4AA8BCAB59F10120010A04001240000000000000000000000FF9000");
        genAcResponse1 = Util.hexToByteArray("77269F2701009F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F0602570324040007000300000000009000");
        genAcResponse2 = Util.hexToByteArray("77269F2701809F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F06015603A4000007000300000100029000");
        genAcResponse3 = Util.hexToByteArray("77269F2701009F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F0601560325A00007010300000100029000");
    }

    /**
     * Script 2: Extended EMV responses with more data
     */
    private void configureScript2Responses(String pan, String year, String month, String serviceCode,
                                           String discretionary, int firstDigit) {
        // GPO Response
        gpoResponse = Util.hexToByteArray("770E82021980940810010101200103009000");

        // Read Record commands
        readRecCommand = Util.hexToByteArray("00B2011400");
        readRecCommand1 = Util.hexToByteArray("00B2012400");
        readRecCommand2 = Util.hexToByteArray("00B2022400");
        readRecCommand3 = Util.hexToByteArray("00B2032400");
        readRecCommand4 = Util.hexToByteArray("00B2022400");
        readRecCommand5 = Util.hexToByteArray("00B2022000");

        String track2Equivalent = buildTrack2Equivalent(pan, year, month, serviceCode, discretionary);
        
        // Record response with track2 equivalent
        String rec = "70" + String.format("%02X", (track2Equivalent.length() + 200) / 2) + 
                     "9F420208405F25032004015F2403" + year + month + "29" +
                     "5A" + String.format("%02X", pan.length() / 2) + pan +
                     "9F4701039F4681B096D8FA329CA82D2E554E74081313AE444D558FBD03787AEBCACB31B0BD5102249DE2A21DECF7D5ED656B2CB362C3FEDD87A2AF88F8EA685DAF047F23829CC49E8C04EB94FA6DB462512CA1DD022F0A7E41029A08479C8996F549669652F2586863B9FC95ABA86A57882395F2CD3B210F517712861DB4077817BFABD8894AF243BA16652FD46CFC42E06484EFF591463201163EB178C33A8A8F098294B21FB400C782D4E1ACB931652A163BB95661D78B9000";
        readRecResponse = Util.hexToByteArray(rec);
        
        readRecResponse1 = Util.hexToByteArray("7081B89F4701039F4681B096D8FA329CA82D2E554E74081313AE444D558FBD03787AEBCACB31B0BD5102249DE2A21DECF7D5ED656B2CB362C3FEDD87A2AF88F8EA685DAF047F23829CC49E8C04EB94FA6DB462512CA1DD022F0A7E41029A08479C8996F549669652F2586863B9FC95ABA86A57882395F2CD3B210F517712861DB4077817BFABD8894AF243BA16652FD46CFC42E06484EFF591463201163EB178C33A8A8F098294B21FB400C782D4E1ACB931652A163BB95661D78B9000");
        readRecResponse2 = Util.hexToByteArray("70078F01069F3201039000");
        readRecResponse3 = Util.hexToByteArray("7081FB9081F8AA280078BEC0DA1020FA073305F4C3A9826779407F7486159F2C84F435605F67EB1D6406F230434B252842B8F2EAEDF229D0C50BB9126F13364C19FC930E5F5A6FEE424035220DD53DF5F692D170C6A50BA12DD7FB456276E7A121CF2A56FCD67B59567A52C08840E50EBB656D848F145030C628C9A1866991A2AEDCB245F5589B0E65598EAE1DDF013FE6D650392D9647389143E733D1D43B48308FDD1E1743C4ED3EECA0DBD7DA8543CC4E01AA82AEF72CAE6BB554F1844DD5A54B50A318E9A16DF78387C44215890575A6938380041F422975A75E4A8B7FEFE4967E748A9A2371D48F35F6EE8A1E46F1D839BC403CCCABD24AE1D685DD9000");
        readRecResponse4 = Util.hexToByteArray("7081B49F4681B0B834223C55B08CD4B58E16DBCC05BA2D8C3EC19A093832BCD1F3382F9DB42A4C518552B285EC929FCA269D4F45A56F76973AEB24A9ECBCBD010F63D56952198BD63E8427FEF356B1B519DC4EFA5E87FA77803BBE94BDE4797CA38C64950751FF8B310E0F36564929B3818064CB6994B634275C62FD7ADB6662B15D2F627C74A8EF30309EBE6F31B03C2E0FDD85DDDF130033BC958A8613935B4EE7B5386E4142FE7FE2AE26F70E00E34C35C3737EA7869000");
        readRecResponse5 = readRecResponse;

        // GEN AC Responses
        String randomHex = getRandomHex(16);
        genAcResponse0 = Util.hexToByteArray("7781A29F2701809F360200079F4B818013783113B4B15DBD5D7211B82B252DF97754F17C4B9BFB9769001F0CC554DC6AAA8B463A0CF8423E2E81824D8FDB18D28DA84DF196E479EF36B6B659872CC6564898F9D2875E8E18A30E3035ECB5FA7200ED7EE969A531530CACADE29CB790B62F300F11E332F0FCA32B7BEDBBEC16B8B70D604E7F22EB99B85F54B4AA8BCAB59F10120010A04001240000000000000000000000FF9000");
        genAcResponse1 = Util.hexToByteArray("77269F2701009F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F0602570324040007000300000000009000");
        genAcResponse2 = Util.hexToByteArray("77269F2701809F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F06015603A4000007000300000100029000");
        genAcResponse3 = Util.hexToByteArray("77269F2701009F3602" + getRandomNumber(4) + "9F2608" + randomHex + "9F100F0601560325A00007010300000100029000");
    }

    private String buildTrack2Equivalent(String pan, String year, String month, String serviceCode, String discretionary) {
        StringBuilder track2 = new StringBuilder();
        track2.append(pan).append("D").append(year).append(month).append(serviceCode);
        if (discretionary != null && !discretionary.isEmpty()) {
            track2.append(discretionary);
        }
        // Pad to even length
        if (track2.length() % 2 != 0) track2.append("F");
        return "57" + String.format("%02X", track2.length() / 2) + track2.toString();
    }

    private String getCardType() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        return prefs.getString(Fixo.SWIPE_KEY_TYPE, Fixo.DEFAULT_TYPE);
    }

    private String getRandomHex(int length) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length) {
            sb.append(Integer.toHexString(random.nextInt(16)));
        }
        return sb.substring(0, length).toUpperCase();
    }

    private String getRandomNumber(int digits) {
        int min = (int) Math.pow(10, digits - 1);
        int max = (int) Math.pow(10, digits) - 1;
        return String.format("%0" + digits + "d", new Random().nextInt(max - min + 1) + min);
    }
}