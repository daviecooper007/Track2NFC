package net.track2world.android.track2nfcmult;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Activity for adding/editing Track 2 card data.
 */
public class GravarTag extends Activity {
    public static TextView cardExpirationTextView;
    public static TextView cardNumberTextView;
    public static TextView currentNameOnCard;

    private EditText swipeDataEditText;
    private RadioGroup typeRadioGroup;
    private RadioGroup typeRadioGroupSpinner;
    private RadioGroup scriptRadioGroup;
    private Spinner spinner;
    private ArrayAdapter<String> spinnerAdapter;
    private DatabaseTrack2NFC database;

    // Same pattern as MainActivity
    private static final Pattern TRACK2_PATTERN = Pattern.compile("(\\d{12,29})=(\\d{2})(\\d{2})(\\d{3})(\\d+)");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_card);

        typeRadioGroup = findViewById(R.id.type);
        typeRadioGroupSpinner = findViewById(R.id.type1);
        scriptRadioGroup = findViewById(R.id.radio_script);
        currentNameOnCard = findViewById(R.id.name_on_card);
        cardNumberTextView = findViewById(R.id.card_number);
        cardExpirationTextView = findViewById(R.id.card_expiration);
        swipeDataEditText = findViewById(R.id.swipe_data);

        database = new DatabaseTrack2NFC(this);
        spinner = findViewById(R.id.spinner1);

        // Display current saved data
        parseTrackData(getSavedSwipeData());
        currentNameOnCard.setText(getSavedName());

        loadSpinner();
    }

    private void loadSpinner() {
        ArrayList<String> cardList = new ArrayList<>(database.getAllData());
        // Add default test card
        cardList.add("4111111111111111=2212201000000000000");
        
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cardList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
    }

    /**
     * Parse and display track 2 data.
     * Returns true if parsing successful.
     */
    private boolean parseTrackData(String track2Data) {
        if (track2Data == null || track2Data.trim().isEmpty()) return false;

        Matcher matcher = TRACK2_PATTERN.matcher(track2Data);
        if (!matcher.matches()) {
            Log.w("GravarTag", "Track2 data doesn't match pattern: " + track2Data);
            return false;
        }

        String pan = matcher.group(1);
        String year = matcher.group(2);
        String month = matcher.group(3);
        String expiration = month + "/" + year;

        // Update UI
        String formattedPan = formatPan(pan);
        if (MainActivity.FrontCardNumber != null) MainActivity.FrontCardNumber.setText(formattedPan);
        if (cardNumberTextView != null) cardNumberTextView.setText(formattedPan);
        if (MainActivity.DataExp != null) MainActivity.DataExp.setText(expiration);
        if (cardExpirationTextView != null) cardExpirationTextView.setText(expiration);
        if (MainActivity.FrontNameCard != null) MainActivity.FrontNameCard.setText(getSavedName());

        // Set card brand
        if (MainActivity.Bandeira != null && pan.length() > 0) {
            int firstDigit = Character.getNumericValue(pan.charAt(0));
            int drawableRes = getCardBrandDrawable(firstDigit);
            if (drawableRes != 0) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), drawableRes);
                MainActivity.Bandeira.setImageBitmap(bitmap);
                MainActivity.Bandeira.getLayoutParams().height = 500;
            }
        }

        Log.d("GravarTag", "Parsed track2: PAN=" + pan + ", Exp=" + expiration);
        return true;
    }

    private String formatPan(String pan) {
        String padded = String.format("%-16s", pan).replace(' ', '0');
        if (padded.length() > 16) padded = padded.substring(0, 16);
        return padded.substring(0, 4) + " " + padded.substring(4, 8) + " " + padded.substring(8, 12) + " " + padded.substring(12, 16);
    }

    private int getCardBrandDrawable(int firstDigit) {
        switch (firstDigit) {
            case 4: return R.drawable.ico_visa;
            case 5: return R.drawable.ico_master;
            case 3: return R.drawable.ico_amex;
            case 6: return R.drawable.ico_discover;
            default: return R.drawable.ico_master;
        }
    }

    private String getSavedSwipeData() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        return prefs.getString(Fixo.SWIPE_DATA_PREF_KEY, Fixo.DEFAULT_SWIPE_DATA);
    }

    private String getSavedName() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        return prefs.getString(Fixo.SWIPE_DATA_PREF_KEY_NAME, Fixo.DEFAULT_NAME);
    }

    private void storeNewSwipeData(String data) {
        PreferenceManager.getDefaultSharedPreferences(this).edit()
                .putString(Fixo.SWIPE_DATA_PREF_KEY, data).apply();
    }

    private void storeNewName(String name) {
        PreferenceManager.getDefaultSharedPreferences(this).edit()
                .putString(Fixo.SWIPE_DATA_PREF_KEY_NAME, name).apply();
    }

    private void storeNewType(String type) {
        PreferenceManager.getDefaultSharedPreferences(this).edit()
                .putString(Fixo.SWIPE_KEY_TYPE, type).apply();
    }

    private void storeSwipeScript(String script) {
        PreferenceManager.getDefaultSharedPreferences(this).edit()
                .putString(Fixo.SWIPE_SCRIPT, script).apply();
    }

    private void showToast(String message, int duration) {
        Toast toast = Toast.makeText(this, message, duration);
        toast.setGravity(android.view.Gravity.CENTER, 0, 0);
        toast.show();
    }

    // Button: Delete selected card
    public void deletCard(View view) {
        String selected = spinner.getSelectedItem().toString();
        database.deletData(selected);
        loadSpinner();
        showToast("Delete Track OK", Toast.LENGTH_SHORT);
    }

    // Button: Clear all cards
    public void ClearAllCards(View view) {
        database.clearAll();
        loadSpinner();
        showToast("Clear All Cards", Toast.LENGTH_SHORT);
    }

    // Button: Write selected card from spinner
    public void inserirSelected(View view) {
        String selected = spinner.getSelectedItem().toString();
        String type = getSelectedType(typeRadioGroupSpinner);
        storeNewType(type);

        boolean success = parseTrackData(selected);
        if (success) {
            storeNewSwipeData(selected);
            showToast("Track2 OK", Toast.LENGTH_SHORT);
        } else {
            showToast("FAILED, Please check Track2", Toast.LENGTH_LONG);
        }
        loadSpinner();
    }

    // Button: Save new card from input
    public void setNewCard(View view) {
        String type = getSelectedType(typeRadioGroup);
        storeNewType(type);

        String input = swipeDataEditText.getText().toString().trim();
        if (input.length() < 10) {
            showToast("Please fill in track 2", Toast.LENGTH_SHORT);
            return;
        }

        boolean success = parseTrackData(input);
        if (success) {
            swipeDataEditText.setText("");
            storeNewSwipeData(input);
            database.insertData(input);
            showToast("Track2 OK", Toast.LENGTH_SHORT);
        } else {
            swipeDataEditText.setText("");
            showToast("FAILED, Please check Track2 format", Toast.LENGTH_LONG);
        }
        loadSpinner();
    }

    // Button: Save cardholder name
    public void writerName(View view) {
        EditText nameEditText = findViewById(R.id.Insert_Name);
        String name = nameEditText.getText().toString().trim();
        if (!name.isEmpty()) {
            storeNewName(name);
            if (currentNameOnCard != null) currentNameOnCard.setText(name);
            if (MainActivity.FrontNameCard != null) MainActivity.FrontNameCard.setText(name);
            showToast("Name OK", Toast.LENGTH_SHORT);
        }
    }

    // Radio button handlers
    public void onRadioButtonClicked(View view) {
        if (view instanceof RadioButton) {
            RadioButton rb = (RadioButton) view;
            if (rb.isChecked()) {
                // Type selection handled in button clicks
            }
        }
    }

    public void onRadioButtonClickedScript(View view) {
        if (view instanceof Button) {
            storeSwipeScript(((Button) view).getText().toString());
        }
    }

    private String getSelectedType(RadioGroup group) {
        int checkedId = group.getCheckedRadioButtonId();
        if (checkedId != -1) {
            RadioButton rb = findViewById(checkedId);
            return rb.getText().toString();
        }
        return Fixo.DEFAULT_TYPE;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        loadSpinner();
        parseTrackData(getSavedSwipeData());
    }
}