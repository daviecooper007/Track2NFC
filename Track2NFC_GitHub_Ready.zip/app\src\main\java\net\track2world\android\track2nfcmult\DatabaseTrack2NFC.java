package net.track2world.android.track2nfcmult;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashSet;
import java.util.Set;

/**
 * Database helper for storing Track 2 data.
 */
public class DatabaseTrack2NFC extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseTrack2NFC";
    private static final String DB_NAME = "track2nfcdb";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "tbtrack2nfc";
    private static final String COL_ID = "id";
    private static final String COL_TRACK2 = "track2";
    private static final String COL_NAME = "name";

    public DatabaseTrack2NFC(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TRACK2 + " TEXT NOT NULL, " +
                COL_NAME + " TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Insert track 2 data.
     */
    public void insertData(String track2) {
        if (track2 == null || track2.trim().isEmpty()) return;
        
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues values = new ContentValues();
            values.put(COL_TRACK2, track2);
            db.insert(TABLE_NAME, null, values);
        } catch (Exception e) {
            Log.e(TAG, "Error inserting track2 data", e);
        } finally {
            db.close();
        }
    }

    /**
     * Delete specific track 2 data.
     */
    public void deletData(String track2) {
        if (track2 == null || track2.trim().isEmpty()) return;
        
        SQLiteDatabase db = getWritableDatabase();
        try {
            // Use parameterized query to prevent SQL injection
            db.delete(TABLE_NAME, COL_TRACK2 + " = ?", new String[]{track2});
        } catch (Exception e) {
            Log.e(TAG, "Error deleting track2 data", e);
        } finally {
            db.close();
        }
    }

    /**
     * Clear all track 2 data.
     */
    public void clearAll() {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(TABLE_NAME, null, null);
        } catch (Exception e) {
            Log.e(TAG, "Error clearing all track2 data", e);
        } finally {
            db.close();
        }
    }

    /**
     * Get all stored track 2 data.
     */
    public Set<String> getAllData() {
        Set<String> result = new HashSet<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, new String[]{COL_TRACK2}, null, null, null, null, COL_ID + " ASC");
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndex(COL_TRACK2);
                do {
                    String track2 = cursor.getString(columnIndex);
                    if (track2 != null && !track2.trim().isEmpty()) {
                        result.add(track2);
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting all track2 data", e);
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return result;
    }
}