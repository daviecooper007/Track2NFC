package net.track2world.android.track2nfcmult;

/**
 * Constants class for the Track2NFC app.
 */
public class Fixo {
    public static final String DEFAULT_NAME = "CLIENT NAME";
    // Default track 2: PAN=4046460664629718, Expiry=1610 (Oct 2016), Service Code=121, Discretionary=0000001810000
    public static final String DEFAULT_SWIPE_DATA = "4046460664629718=16101210000018100000";
    public static final String DEFAULT_TYPE = "Credit";
    public static final String SWIPE_DATA_PREF_KEY = "SWIPE_DATA";
    public static final String SWIPE_DATA_PREF_KEY_NAME = "SWIPE_DATA_NAME";
    public static final String SWIPE_KEY_TYPE = "SWIPE_KEY_TYPE";
    public static final String SWIPE_SCRIPT = "script_1";
    public static final String SWIPE_SCRIPT_DEFAULT = "script_1";
}