package net.track2world.android.track2nfcmult;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.nfc.NfcAdapter;
import android.nfc.cardemulation.CardEmulation;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Main activity for Track2NFC app.
 * Displays card info and allows cycling through saved cards.
 */
public class MainActivity extends Activity {
    public static ImageView Bandeira = null;
    public static TextView DataExp = null;
    public static TextView FrontCardNumber = null;
    public static TextView FrontNameCard = null;
    public static ListIterator<String> infoL = null;
    public static Set<String> cardDataSet = null;

    private DatabaseTrack2NFC database;
    private static final String TAG = "MainActivity";
    private static final StringBuilder logCache = new StringBuilder();
    private static final SimpleDateFormat timeStampFmt = new SimpleDateFormat("HH:mm:ss.SSS  ", Locale.US);

    // Regex pattern for Track 2 data: PAN=YYMMDDServiceCodeDiscretionaryData
    // PAN: 12-29 digits, = separator, YY: 2 digits, MM: 2 digits, Service Code: 3 digits, Discretionary: 1+ digits
    private static final Pattern TRACK2_PATTERN = Pattern.compile("(\\d{12,29})=(\\d{2})(\\d{2})(\\d{3})(\\d+)");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrontNameCard = findViewById(R.id.name_client);
        FrontCardNumber = findViewById(R.id.card_front);
        Bandeira = findViewById(R.id.bandeira);
        DataExp = findViewById(R.id.card_exp);

        String savedName = getSavedName();
        String savedSwipeData = getSavedSwipeData();

        ImageView nfcLogo = findViewById(R.id.LogNFC);
        nfcLogo.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.nfc_logo));
        nfcLogo.getLayoutParams().height = 700;
        nfcLogo.getLayoutParams().width = 700;

        database = new DatabaseTrack2NFC(this);
        loadCardData();

        // NFC Logo click - go to previous card
        nfcLogo.setOnClickListener(v -> {
            if (infoL != null && infoL.hasPrevious()) {
                String previous = infoL.previous();
                updateCardDisplay(previous);
                saveSwipeData(previous);
                Log.d(TAG, "Previous card: " + previous);
            }
        });

        // Card brand click - go to next card
        if (Bandeira != null) {
            Bandeira.setOnClickListener(v -> {
                if (infoL != null && infoL.hasNext()) {
                    String next = infoL.next();
                    updateCardDisplay(next);
                    saveSwipeData(next);
                    Log.d(TAG, "Next card: " + next);
                }
            });
        }

        // Expiration click - reload card data
        if (DataExp != null) {
            DataExp.setOnClickListener(v -> loadCardData());
        }

        // Display saved card data on startup
        updateCardDisplay(savedSwipeData);
        if (FrontNameCard != null) {
            FrontNameCard.setText(savedName);
        }

        // Apply custom fonts
        applyCustomFonts();

        // Set up NFC HCE service as default payment
        setupNfcPayment();
    }

    private void loadCardData() {
        ArrayList<String> cardList = new ArrayList<>(database.getAllData());
        // Add default test card if empty
        if (cardList.isEmpty()) {
            cardList.add("4111111111111111=2212201000000000000");
        }
        infoL = cardList.listIterator();
        cardDataSet = database.getAllData();
        
        for (String card : cardList) {
            Log.d(TAG, "Loaded card: " + card);
        }
    }

    private void applyCustomFonts() {
        try {
            Typeface kreditFont = Typeface.createFromAsset(getAssets(), "fonts/kredit.ttf");
            Typeface kreditBackFont = Typeface.createFromAsset(getAssets(), "fonts/kredit back.ttf");

            if (FrontCardNumber != null) {
                FrontCardNumber.setTypeface(kreditFont);
                FrontCardNumber.setTextSize(45);
                FrontCardNumber.getPaint().setShader(new LinearGradient(
                        2, 0, 4, 60,
                        new int[]{Color.parseColor("#ffd700"), Color.parseColor("#ffd700"), Color.parseColor("#ffd700")},
                        new float[]{0.0f, 0.5f, 1.0f},
                        Shader.TileMode.MIRROR));
                FrontCardNumber.setRotation(90);
            }

            if (FrontNameCard != null) {
                FrontNameCard.setTypeface(kreditBackFont);
                FrontNameCard.setTextSize(35);
                FrontNameCard.setRotation(90);
                FrontNameCard.setTextColor(Color.WHITE);
            }

            if (DataExp != null) {
                DataExp.setTypeface(kreditBackFont);
                DataExp.setTextSize(30);
                DataExp.setRotation(90);
                DataExp.setTextColor(Color.WHITE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading custom fonts", e);
        }
    }

    private void setupNfcPayment() {
        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter != null) {
            CardEmulation cardEmulation = CardEmulation.getInstance(nfcAdapter);
            ComponentName componentName = new ComponentName(this, ServicoPagamento.class);

            if (cardEmulation != null) {
                if (!cardEmulation.isDefaultServiceForCategory(componentName, "payment")) {
                    Intent intent = new Intent(CardEmulation.ACTION_CHANGE_DEFAULT);
                    intent.putExtra(CardEmulation.EXTRA_CATEGORY, "payment");
                    intent.putExtra(CardEmulation.EXTRA_SERVICE_COMPONENT, componentName);
                    startActivityForResult(intent, 0);
                    log(TAG, "Requesting to set Track2NFC as default payment service");
                } else {
                    log(TAG, "Track2NFC is already default payment service");
                }
            }
        }
    }

    private void updateCardDisplay(String track2Data) {
        if (track2Data == null || track2Data.trim().isEmpty()) return;

        Matcher matcher = TRACK2_PATTERN.matcher(track2Data);
        if (matcher.matches()) {
            String pan = matcher.group(1);
            String year = matcher.group(2);
            String month = matcher.group(3);
            // String serviceCode = matcher.group(4);
            // String discretionary = matcher.group(5);

            // Format expiration as MM/YY
            String expiration = month + "/" + year;

            // Format PAN with spaces (groups of 4)
            String formattedPan = formatPan(pan);

            if (DataExp != null) DataExp.setText(expiration);
            if (FrontCardNumber != null) FrontCardNumber.setText(formattedPan);

            // Set card brand based on first digit
            if (Bandeira != null && pan.length() > 0) {
                int firstDigit = Character.getNumericValue(pan.charAt(0));
                int drawableRes = getCardBrandDrawable(firstDigit);
                if (drawableRes != 0) {
                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), drawableRes);
                    Bandeira.setImageBitmap(bitmap);
                    Bandeira.getLayoutParams().height = 500;
                }
            }
        } else {
            Log.w(TAG, "Track2 data doesn't match expected pattern: " + track2Data);
        }
    }

    private String formatPan(String pan) {
        // Pad to at least 16 chars for display
        String padded = String.format("%-16s", pan).replace(' ', '0');
        if (padded.length() > 16) padded = padded.substring(0, 16);
        return padded.substring(0, 4) + " " + padded.substring(4, 8) + " " + padded.substring(8, 12) + " " + padded.substring(12, 16);
    }

    private int getCardBrandDrawable(int firstDigit) {
        switch (firstDigit) {
            case 4: return R.drawable.ico_visa;      // Visa
            case 5: return R.drawable.ico_master;    // Mastercard
            case 3: return R.drawable.ico_amex;      // Amex
            case 6: return R.drawable.ico_discover;  // Discover
            default: return R.drawable.ico_master;
        }
    }

    private String getSavedName() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        return prefs.getString(Fixo.SWIPE_DATA_PREF_KEY_NAME, Fixo.DEFAULT_NAME);
    }

    private String getSavedSwipeData() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        return prefs.getString(Fixo.SWIPE_DATA_PREF_KEY, Fixo.DEFAULT_SWIPE_DATA);
    }

    private void saveSwipeData(String track2Data) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
        editor.putString(Fixo.SWIPE_DATA_PREF_KEY, track2Data);
        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_set_card) {
            startActivity(new Intent(this, GravarTag.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        loadCardData();
    }

    /**
     * Security checks - disabled for debug builds to allow testing
     */
    private void performSecurityChecks() {
        if (isDebugBuild()) {
            Log.d(TAG, "Debug build - skipping security checks");
            return;
        }

        checkAppSignature(this);
        checkEmulator();
        verifyInstaller(this);
    }

    private boolean isDebugBuild() {
        return (getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    public static int checkAppSignature(Context context) {
        try {
            String expectedSig = "ZtLNR09VUbGJAR1ZYAqeL/UFae0="; // Original signature
            for (Signature signature : context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 64).signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String actualSig = Base64.encodeToString(md.digest(), Base64.NO_WRAP);
                Log.d("REMOVE_ME", "Include this string as a value for SIGNATURE: " + actualSig);
                if (expectedSig.equals(actualSig)) {
                    return 0; // VALID
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Signature check failed", e);
        }
        return 1; // INVALID
    }

    public static boolean checkEmulator() {
        try {
            String hardware = getSystemProperty("ro.hardware");
            String kernel = getSystemProperty("ro.kernel.qemu");
            String model = getSystemProperty("ro.product.model");
            
            if (hardware != null && hardware.contains("goldfish")) return true;
            if (kernel != null && kernel.length() > 0) return true;
            if ("sdk".equals(model)) return true;
        } catch (Exception e) {
            Log.e(TAG, "Emulator check failed", e);
        }
        return false;
    }

    private static String getSystemProperty(String key) {
        try {
            Class<?> cls = Class.forName("android.os.SystemProperties");
            return (String) cls.getMethod("get", String.class).invoke(cls, key);
        } catch (Exception e) {
            return "";
        }
    }

    public static boolean verifyInstaller(Context context) {
        try {
            String installer = context.getPackageManager().getInstallerPackageName(context.getPackageName());
            return installer != null && installer.startsWith("com.android.vending");
        } catch (Exception e) {
            return false;
        }
    }

    private static void log(String tag, Object... args) {
        StringBuilder sb = new StringBuilder();
        for (Object obj : args) {
            sb.append(obj.toString());
        }
        logCache.append(timeStampFmt.format(new Date())).append(tag).append(" ").append(sb).append('\n');
        Log.d(tag, sb.toString());
    }

    public static void sendLog(String tag, String... messages) {
        // Placeholder for log sending functionality
        for (String msg : messages) {
            Log.d(tag, msg);
        }
    }
}